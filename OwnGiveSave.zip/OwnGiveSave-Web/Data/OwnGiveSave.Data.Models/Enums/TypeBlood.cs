﻿namespace OwnGiveSave.Data.Models.Enums
{
    public enum TypeBlood
    {
        A = 0,
        B = 1,
        AB = 2,
        O = 3,
    }
}
