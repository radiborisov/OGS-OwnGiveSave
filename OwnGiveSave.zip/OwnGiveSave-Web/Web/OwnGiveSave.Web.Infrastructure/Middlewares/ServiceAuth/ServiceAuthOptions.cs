﻿namespace OwnGiveSave.Web.Infrastructure.Middlewares.ServiceAuth
{
    public class ServiceAuthOptions
    {
        public string Token { get; set; }
    }
}
